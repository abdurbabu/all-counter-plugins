<?php
ob_start();
session_start();


require_once 'class/Plugins.php';
$Plugins = new Plugins();
echo $Plugins->get_ip();
echo "<br>";
echo $Plugins->get_ref();

echo "<br>";
echo $Plugins->get_os();


?>

<a href='index.php'>Home</a>
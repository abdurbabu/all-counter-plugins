<?php
/**
This Library Will Help You to make effective Plugin for Your Website. 
Author : Abdur Rahaman
Website: http://webreciter.com 
Email: abdur.babu81@gmail.com
Facebook: http://facebook.com/abdur.babu

This Library Will Help You To Make Visitor Counter, Users Platform Counter, Users Browser Counter, Reffrer Urls. 


*/


class Plugins{
	protected $user_agent;
	
	
	public function get_ip(){
	
		 $ip = $_SERVER['REMOTE_ADDR']; 
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}	 
		return $ip;	
	}

// Get visitors Borwser. 
	
	public function get_browser(){
			
			$agent = $_SERVER['HTTP_USER_AGENT'];
				$name = 'NA';
				if (preg_match('/MSIE/i', $agent) && !preg_match('/Opera/i', $agent)) {
					$name = 'Internet Explorer';
				} elseif (preg_match('/Firefox/i', $agent)) {
					$name = 'Mozilla Firefox';
				} elseif (preg_match('/Chrome/i', $agent)) {
					$name = 'Google Chrome';
				} elseif (preg_match('/Safari/i', $agent)) {
					$name = 'Apple Safari';
				} elseif (preg_match('/Opera/i', $agent)) {
					$name = 'Opera';
				} elseif (preg_match('/Netscape/i', $agent)) {
					$name = 'Netscape';
				}


				return $name;
	}
// Get referrer Website To use this method You have to start session..
	
	
	public function get_ref(){		
		if(isset($_SERVER["HTTP_REFERER"])){
			return $_SERVER["HTTP_REFERER"];
		}else{
			return $_SESSION["origURL"];
		}		
	}

	
	// Get user Operation System	
	
	public function get_os(){
		
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
		
	$os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );

    foreach ($os_array as $regex => $value) { 

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;
	}

}